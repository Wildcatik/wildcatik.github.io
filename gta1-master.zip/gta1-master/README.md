 


> Открыть эту страницу в [https://wildcatik.github.io/gta1/](https://wildcatik.github.io/gta1/)

## Использовать это расширение

Этот репозиторий может быть добавлен в MakeCode как **расширение**.

* открыть [https://arcade.makecode.com/](https://arcade.makecode.com/)
* нажмите на **Новый проект**
* нажмите **Расширения** в меню-шестерёнке
* найдите **https://github.com/wildcatik/gta1** и импортируйте

## Править этот проект ![Build status badge](https://github.com/wildcatik/gta1/workflows/MakeCode/badge.svg)

Редактировать этот репозиторий в MakeCode.

* открыть [https://arcade.makecode.com/](https://arcade.makecode.com/)
* нажмите на **Импорт**, затем **Импорт URL**
* вставьте **https://github.com/wildcatik/gta1** и нажмите Импорт

## Blocks preview

This image shows the blocks code from the last commit in master.
This image may take a few minutes to refresh.

![A rendered view of the blocks](https://github.com/wildcatik/gta1/raw/master/.github/makecode/blocks.png)

#### Метаданные (используются для поиска, рендеринга)

* for PXT/arcade
<script src="https://makecode.com/gh-pages-embed.js"></script><script>makeCodeRender("{{ site.makecode.home_url }}", "{{ site.github.owner_name }}/{{ site.github.repository_name }}");</script>
